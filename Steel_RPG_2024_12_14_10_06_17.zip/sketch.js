  let scene = 1; //scene tracker
  
  let str = 1;
  let dex = 1;
  let int = 1;
  let cha = 1;
  
  let dragonimg;
  let deathimg;
  let homeimg;
  let humimg;
  let cullimg;
  let pathimg;
  let skelimg;
  let crossimg;

  let textfade = 0; // box for making text appear more slowly, should move down with each scene
  
  let rollresult = 0;

  var Humphrey = false;

  let MagicMissile = 0;
  let Fireball = 0;
  let GhostSound = 0;

  let spellbook = 1;
  let sword = 0;
  let longbow = 0;

  let hasPlayed = false;

function preload(){
  dragonimg = loadImage("Dragon.jpeg")
  deathimg = loadImage("Death.jpg")
  homeimg = loadImage("Home.jpg")
  humimg = loadImage("Humphrey.jpg")
  cullimg = loadImage("Cullafrit.jpg")
  pathimg = loadImage("Path.jpg")
  skelimg = loadImage("Skeleton.jpg")
  crossimg = loadImage("Crossroad.jpg")
  sound1 = loadSound("01Hide.m4a")
}

function setup() {
  createCanvas(1100, 900);
  
  
  //Progression = build character via point buy or questionarre, point buy first for simplicity
  //plot scene
  //forge scene
  //plot scene
  //create 3 scenes of checks, choices and combat using rolls and rng
  // magic --- at crossroads meet, if any spells learned, will unlock second page or spells of class, +2-3 spells
  // arcane, precise and minimalistic, simple, magic missile base, int 
  // chaos, explosive and costly, risky on chance, fireball base, int dex
  // illusion, flashy and sneaky, sneaky, ghost sound base, int cha dex
  // morphic, moves and shapes, risky on how, variant
  
  // // scene index
  // 1 title screen
  // 2  intro story
  // 3  character building 1
  // 4   character building 2
  // 5  character building 3
  // 6  start of the adventure
  // 7  bandit humphrey encounter
  // 8  crossroads choice
  // 9  death
  // 10  stillborn swamp encounter with giant bug-like Cullafrit
  // 11 stillborn swamp wikwaks phase 1, 2 sentries and sleeping wikwaks /// CUT and create wild pyromancer or undead knight?
 
  // 13 Forest solve the fae riddle
  // 14 fae riddle failed, bog monster
  // 16 fae riddle failed, fallen knight
  // 17 fae riddle success, one more then if fail fallen knight
  // 18 extra in case
  // 19 extra in case
  // 20 graven fields, intermission
  
  
  
  
  
  
  
}


function rolldice(){
  
  rollresult = random(1,7);

}

function draw() {
  
  
   if (!sound1.isPlaying() && !hasPlayed) {
    sound1.play();
    hasPlayed = true;
   }
   
  if (scene === 1) {
    drawScene1();
  } else if (scene === 2) {
    drawScene2();
  } else if (scene === 3) {
    drawScene3();
  } else if (scene === 4) {
    drawScene4();
  }
  else if (scene === 5) {
    drawScene5();
  }
  else if (scene === 6) {
    drawScene6();
  }
  else if (scene === 7) {
    drawScene7();
  }
  else if (scene === 8) {
    drawScene8();
  }
  else if (scene === 9) {
    drawScene9();
  }
    else if (scene === 10) {
    drawScene10();
  }
      else if (scene === 105) {
    drawScene105();
  }
        else if (scene === 106) {
    drawScene106();
  }
        else if (scene === 107) {
    drawScene107();
  }
    else if (scene === 11) {
    drawScene11();
  }
      else if (scene === 115) {
    drawScene11();
  }
      else if (scene === 116) {
    drawScene11();
  }
    else if (scene === 12) {
    drawScene12();
  }    
  else if (scene === 125) {
    drawScene12();
  }
      else if (scene === 13) {
    drawScene13();
  }
      else if (scene === 14) {
    drawScene14();
  }
      else if (scene === 15) {
    drawScene15();
  }
      else if (scene === 16) {
    drawScene16();
  }
      else if (scene === 17) {
    drawScene17();
  }
      else if (scene === 18) {
    drawScene18();
  }
      else if (scene === 19) {
    drawScene19();
  }
} 
  
function drawScene1() {
  background(0)
  
  fill(255);
  //rect(360, 465, 270, 40);
  
  
  fill(255);
  textSize(40);
  textAlign(CENTER);
  text("Steel",width / 2, height / 2 - 50);
  text("Click anywhere to Start Game", width / 2, height / 2);
    
//      if(mouseX > 145 && mouseX < 304 && mouseY > 160 && mouseY < 365){
       
//     scene = 2;
//      }
    
   
}

function drawScene2() {
  clear();
  background(0)
  image(dragonimg, 0, 0);
     textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);

  fill(255);
  text("Prologue story", width / 2, height / 2 - 300);
  text("Click anywhere to continue", width / 2, height / 2 - 200);
  text("Long story short, youve been framed for a crime", width / 2, height / 2 - 100);
  text("of a necromancer whose lair is a days travel out of town", width / 2, height / 2);
  text("bring him to justice and clear your name", width / 2, height / 2 + 100);
  
    fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
    }
 


function drawScene3(){
  clear();
  background(0);
  image(homeimg, 300, 0);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("Before you left on your journey", width / 2, height / 2 - 300);
  text("in addition to your knife and some food", width / 2, height / 2 - 200);
  text("You decided to take with you", width / 2, height / 2 - 100);
  


  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  
  textSize(20)
  fill(255, 0, 0);
  text("The large sword and helmet ", width / 2 - 300, height / 2 + 350);
  text("your parents left you", width / 2 - 300, height / 2 + 380);
  fill(0, 200, 100);
  text("Your hunting bow and arrows", width / 2 - 110, height / 2 + 230);
  fill(0, 0, 255);
  text("Your magic staff and", width / 2 + 90, height / 2 + 350);
  text(" your tome stash", width / 2 + 90, height / 2 + 380);
  fill(255, 0, 255);
  text("The enchanted tooth you ", width / 2 + 290, height / 2 + 210);
  text(" scammed off a witch", width / 2 + 290, height / 2 + 240);
  
  // image(homeimg, 0, 0);
}



function drawScene4(){
  
     clear();
  background(0);
  image(homeimg, 300, 0);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("The peoples of Hargothia are born under star signs", width / 2, height / 2 - 300);
  text("of different animals sacred to its peoples", width / 2, height / 2 - 200);
  text("Which sign were you born under", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(255, 0, 0);
  text("The Dragon", width / 2 - 300, height / 2 + 370);
  fill(0, 200, 100);
  text("The Serpent", width / 2 - 110, height / 2 + 230);
  fill(0, 0, 255);
  text("The Sphinx", width / 2 + 90, height / 2 + 370);
  fill(255, 0, 255);
  text("The Corvid", width / 2 + 290, height / 2 + 230);
  
  
}

function drawScene5(){
  
          clear();
  background(0);
  image(homeimg, 300, 0);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("The fateful afternoon before you were", width / 2, height / 2 - 300);
  text("summoned before the mayor,", width / 2, height / 2 - 200);
  text("what were you doing?", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  textSize(23);
  fill(255, 0, 0);
  text("Threatening the tax collector", width / 2 - 300, height / 2 + 370);
  fill(0, 200, 100);
  text("Cooking a good stew", width / 2 - 110, height / 2 + 230);
  fill(0, 0, 255);
  text("Studying your tomes", width / 2 + 90, height / 2 + 370);
  fill(255, 0, 255);
  text("Swooning the barmaid", width / 2 + 290, height / 2 + 230);
}

function drawScene6(){
  
           clear();
  background(0);
  image(pathimg, 300, 0);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("The sun sets as you leave town, a small mote of rage bellowing", width / 2, height / 2 - 300);
  text("in your mind at the thought of being convicted so quickly and tasked", width / 2, height / 2 - 200);
  text("with this quest. You continue on as your adventure unfolds before you", width / 2, height / 2 - 100);
  text("may luck be on your side", width / 2, height / 2);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("continue", width / 2 - 300, height / 2 + 370);
  text("continue", width / 2 - 110, height / 2 + 230);
  text("continue", width / 2 + 90, height / 2 + 370);
  text("continue", width / 2 + 290, height / 2 + 230);
  
  
}
function drawScene7(){
       clear();
  background(0);
  
  
  
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("As you leave the town you are ambushed on", width / 2, height / 2 - 100);
  text("it's outskirts by a bandit, his hungry eyes", width / 2, height / 2 - 50);
  text("showing its clear intention as its brandishes a", width / 2, height / 2);
  text("blade. As he runs toward you and winds up", width / 2, height / 2 + 50);
  text("his axe for a high strike, you decide to", width / 2, height / 2 + 100);
  
  image(humimg, 100, 100, width / 2, height / 2 - 300);

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  textSize(20);
  fill(0);
  text("Duck and swing at him", width / 2 - 300, height / 2 + 370);
  if(longbow==1){text("Shoot at him from a distance", width / 2 - 110, height / 2 + 230);}
  if(spellbook==1){text("Cast magic missile", width / 2 + 90, height / 2 + 370);}
  text("Sidestep and convince ", width / 2 + 290, height / 2 + 210);
  text(" him to join you", width / 2 + 290, height / 2 + 240);
}

function drawScene8(){
       clear();
  background(0);
  image(crossimg, 300, 60);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You continue down the path after your encounter", width / 2, height / 2 - 150);
  text("and come to a crossroads. The left sign reads", width / 2, height / 2 - 100);
  text("'Stillborne Swamp' while the right one", width / 2, height / 2 - 50);
  text("reads 'Foruscu Wood'", width / 2, height / 2);
  text("Which path do you take", width / 2, height / 2 + 100);
  
    
  
  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("Stillborne Swamp", width / 2 - 300, height / 2 + 370);
  text("Stillborne Swamp", width / 2 - 110, height / 2 + 230);
  text("Foruscu Wood", width / 2 + 90, height / 2 + 370);
  text("Foruscu Wood", width / 2 + 290, height / 2 + 230);
}

function drawScene9(){
       clear();
  background(0);
  
  textSize(50);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(200, 0, 0);


  
    image(deathimg, 0, 0);
    text("You Have Died", width / 2, height / 2 - 200);
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(255);
  text("Reset", width / 2 - 300, height / 2 + 370);
  text("Reset", width / 2 - 110, height / 2 + 230);
  text("Reset", width / 2 + 90, height / 2 + 370);
  text("Reset", width / 2 + 290, height / 2 + 230);
}

function drawScene10(){
       clear();
  background(0);
  image(cullimg, 300, 60);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("As you move into the sulferous Stillborne swamp", width / 2, height / 2 - 400);
  text("something starts to chitter and clack in the brush covered bog", width / 2, height / 2 - 350);
  text("As it gets closer you see it belongs to a giant, grotesque, bug like creature", width / 2, height / 2 - 300);
  text("That emerges towering above the bog, with its claws agape", width / 2, height / 2 - 250);
  
   text("and hunting beneath its featureless, pyramid shaped exoskeletous skull", width / 2, height / 2 - 200);
  
  if(int > 3){
    text("your memory identifies the creature as a Cullafrit", width / 2, height / 2 - 100);
    text("a blind predator with enormous strength, speed", width / 2, height / 2 - 150);
    text("and sound sensitivity but exceptionally low intelligence and easily distracted", width / 2, height / 2 - 50);
  }

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  textSize(18);
  text("Run", width / 2 - 300, height / 2 + 370);
  if(sword == 1){text("Ready a strike to cut ", width / 2 - 110, height / 2 + 210);}
   text(" off an appendage", width / 2 - 110, height / 2 + 240);
  text("Take a few seconds as it ", width / 2 + 90, height / 2 + 350);
  text(" approaches and Think up something", width / 2 + 95, height / 2 + 380);
  text("Hide", width / 2 + 290, height / 2 + 230);
}

function drawScene105(){
       clear();
  background(0);
  image(cullimg, 300, 60);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You take a few seconds to come up with an idea", width / 2, height / 2 - 300);
  text("as the beast approaches and probes around", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  
  
  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  textSize(20);
  text("Throw a rock and hide", width / 2 - 300, height / 2 + 370);
  text("Look for weak points", width / 2 - 110, height / 2 + 230);
  text("Imitate its ", width / 2 + 90, height / 2 + 350);
    text(" noises and movments", width / 2 + 90, height / 2 + 380);
  if(spellbook==1){text("Cast a spell", width / 2 + 290, height / 2 + 210);  
  text("from your spellbook", width / 2 + 290, height / 2 + 240);}
}

function drawScene106(){
  
           clear();
  background(0);
  image(cullimg, 300, 60);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You study it for weak points and find", width / 2, height / 2 - 300);
  text("it has what looks like a rotting and injured hind leg", width / 2, height / 2 - 200);
  text("it looks exceptionally brittle, you decide to", width / 2, height / 2 - 100);
  
  
  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("Wait,then pounce and strike at the leg", width / 2 - 300, height / 2 + 370);
  text("Charge the leg and cleave it", width / 2 - 110, height / 2 + 230);
  if(int > 6){text("Ignite the flammable fungus with a fire spell", width / 2 + 90, height / 2 + 370);}
  if(Humphrey == true){text("Motion to Humphrey to cut off its hind leg", width / 2 + 290, height / 2 + 230);}
  
  
}

function drawScene107(){
  
           clear();
  background(0);
  image(cullimg, 300, 60);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You get out your spellbook and", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  

 
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("Cast Magic Missile", width / 2 - 300, height / 2 + 370);
  text("Cast Fireball", width / 2 - 110, height / 2 + 230);
  text("Cast Ghost sound", width / 2 + 90, height / 2 + 370);
  // text("", width / 2 + 290, height / 2 + 230);
  
  
}

function drawScene11(){
       clear();
  background(0);
  image(skelimg, 300, 30);
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You continue down the ruined path and come upon", width / 2, height / 2 - 300);
  text("smoldering craters filled with a vile sulfur smelling liquid.", width / 2, height / 2 - 200);
  text("Guarding the mountain pass is a skeletal holding a broad obsidian sword", width / 2, height / 2 - 100);
  text("and has a flaming whip floating beside him.", width / 2, height / 2 - 100);
  

  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 210);
  text("", width / 2 - 110, height / 2 + 240);
  text("", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}
function drawScene115(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You take a second to plan to", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  textSize(20)
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  
  if(dex > 4){text("", width / 2 - 110, height / 2 + 210);
  text("", width / 2 - 110, height / 2 + 240);
             }
  text("Cast a spell", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene116(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You whip out your spellbook", width / 2, height / 2 - 300);
  text("and turn the pages to cast", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("Cast Magic Missile", width / 2 - 300, height / 2 + 370);
  text("Cast Fireball", width / 2 - 110, height / 2 + 230);
  text("Cast Ghost Sound", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene12(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 230);
  text("Cast a spell", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene125(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You whip out your spellbook before", width / 2, height / 2 - 300);
  text("the creatures are upon you and cast", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("Cast Magic Missile", width / 2 - 300, height / 2 + 370);
  text("Cast Fireball", width / 2 - 110, height / 2 + 230);
  text("Cast Ghost Sound", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene13(){
       clear();
  background(0);
  
  textSize(20);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You go down the path through the Foruscu forest, alit with ", width / 2, height / 2 - 400);
  text("redwoods and fluorescent blue crystals. You see glimpses of", width / 2, height / 2 - 350);
  text("small faeries flitting and flickering in the distance. As you", width / 2, height / 2 - 300);
  text("wander through the forest, the path drifts off into the forest valley.", width / 2, height / 2 - 250);
  text("Next to the edge of the chasm is a stone that reads", width / 2, height / 2 - 200);
  textSize(30);
  text("Speak your answer. You keep it, but once its shared", width / 2, height / 2 - 150);
  text("its gone forever. What is it?", width / 2, height / 2 - 100);
  textSize(20);

  // You keep it, but once its shared its gone forever. What is it?
  // Secret
  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("A Meal", width / 2 - 300, height / 2 + 370);
  text("A Secret", width / 2 - 110, height / 2 + 230);
  text("A Dream", width / 2 + 90, height / 2 + 370);
  text("A Life", width / 2 + 290, height / 2 + 230);
}

function drawScene14(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("You tumble down the chasm into the forest bog, ever green", width / 2, height / 2 - 300);
  text("with the smell of rot filling your nostrils as you the bogwater ", width / 2, height / 2 - 200);
  text("breaks your fall. As you stand up from the carrion filled", width / 2, height / 2 - 100);
  text("much and waist deep water, you see a very large furred humanoid", width / 2, height / 2 - 100);
  text("leaning over the pool you are in. In a gurgly voice as ", width / 2, height / 2 - 100);
  text("its single eye and grin grow wide, it growls ", width / 2, height / 2 - 100);
  text("'You no dead yet, but I see her in you shoulder. We are'", width / 2, height / 2 - 100);
  text("'now your fate? Bwo ho ha ho ho'. It laughs and gapes as it saunters toward you", width / 2, height / 2 - 100);
  text(" you decide to", width / 2, height / 2 - 100);
  
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("Charge it valorously", width / 2 - 300, height / 2 + 370);
  text("Convince it otherwise", width / 2 - 110, height / 2 + 230);
  if(spellbook==1){text("Cast a Spell", width / 2 + 90, height / 2 + 370);}
  text("Run", width / 2 + 290, height / 2 + 230);
}

function drawScene145(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  text("", width / 2, height / 2 - 100);
  text(" ", width / 2, height / 2 - 100);
  text(" ", width / 2, height / 2 - 100);
  text("", width / 2, height / 2 - 100);
  text("'", width / 2, height / 2 - 100);
  text(" ", width / 2, height / 2 - 100);
  
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 230);
  text("", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene15(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("challenge if answered wrong", width / 2, height / 2 - 300);
  text("breaks your fall. You see a flickering light in the distance that begins", width / 2, height / 2 - 200);
  text("to float and sputter towards you. As zaps of energy flicker begin to flicker from it violently", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 230);
  text("", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene16(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 230);
  text("", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene17(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("A luminescent sparkling blue and purple bridge across the chasm opens up", width / 2, height / 2 - 300);
  text("to what looks like the other side of the wood. The bridge carries you high above", width / 2, height / 2 - 270);
  text("the forest valley and to the over the trees to the other side. As you come to the other", width / 2, height / 2 - 240);
  text("side of the forest you find yourself in what looks like a faerie village. The faeries", width / 2, height / 2 - 200);
  text("all swarm around a great fae woman and oggle at you. The great fae witch beckons you and asks", width / 2, height / 2 - 100);
  text("'You wish to reach the other side of our wood?'", width / 2, height / 2 - 50);
   text("'Answer me this'", width / 2, height / 2 - 20);
   text("'As I was going to The Saint of Slives, '", width / 2, height / 2 + 10);
  text("'I met a man with seven wives, '", width / 2, height / 2 + 40);
  text("'Each wife had seven sacks , '", width / 2, height / 2 + 70);
  text("'Each sack had seven cats, '", width / 2, height / 2 + 100);
  text("'Each cat had seven kits, '", width / 2, height / 2 + 130);
  text("'Kits, cats, sacks, and wives, '", width / 2, height / 2 + 160);
  text("'How many were going to The Saint of Slives? '", width / 2, height / 2 + 190);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("None", width / 2 - 300, height / 2 + 370);
  text("Seven", width / 2 - 110, height / 2 + 230);
  text("Fourteen", width / 2 + 90, height / 2 + 370);
  text("One", width / 2 + 290, height / 2 + 230);
}

function drawScene18(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 230);
  text("", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}

function drawScene19(){
       clear();
  background(0);
  
  textSize(30);
  textAlign(CENTER);
  //textAlign(TOP);
  fill(255);
  text("", width / 2, height / 2 - 300);
  text("", width / 2, height / 2 - 200);
  text("", width / 2, height / 2 - 100);
  

  
  fill(0);
  rect(0,textfade,1100,900);
  
  textfade = textfade + 3;
  
  fill(222,222,222);
  
  rect(100, 765, 300, 80);
  
  rect(300, 625, 300, 80);
  
  rect(500, 765, 300, 80);
       
  rect(700, 625, 300, 80);
  
  fill(0);
  text("", width / 2 - 300, height / 2 + 370);
  text("", width / 2 - 110, height / 2 + 230);
  text("", width / 2 + 90, height / 2 + 370);
  text("", width / 2 + 290, height / 2 + 230);
}







function mousePressed() {
  textfade = 0;  
  
    if(scene === 1){
    
     if(mouseX > 0 && mouseX < 800 && mouseY > 0 && mouseY < 800){
       
    scene = 2;
     }

    }
  
      else if(scene === 2){
    
     if(mouseX > 0 && mouseX < 800 && mouseY > 0 && mouseY < 800){
       console.log('Game log');
    scene = 3;
     }

    }
  
        
  //scene 3
  
  else if(scene === 3){
    
     if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       
    str = str + 3;
       console.log('str = ',str);
       console.log('You have aqcuired a great weapon',str);
       sword = 1;
       
       scene = 4;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){
       
    dex = dex + 3;
       console.log('dex = ', dex);
        console.log('You have aqcuired a longbow');
       longbow = 1;
                 
       scene = 4;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){
       
    int = int + 3;
       console.log('int = ',int);
       
       scene = 4;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){
       
    cha = cha + 3;
       console.log('cha = ',cha);
       
       scene = 4;
     }

    }
  
  //scene 4        
  
  else if(scene === 4){
    
     if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       
    str = str + 2;
       console.log('str = ',str);
       
       scene = 5;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){
       
    dex = dex + 2;
       console.log('dex = ', dex);
       
       scene = 5;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){
       
    int = int + 2;
       console.log('int = ',int);
       
       scene = 5;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){
       
    cha = cha + 2;
       console.log('cha = ',cha);
       
       scene = 5;
     }

    }
  
    else if(scene === 5){
    
     if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       
    str = str + 1;
       console.log('str = ',str);
       
       scene = 6;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){
       
    dex = dex + 1;
       console.log('dex = ', dex);
       
       scene = 6;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){
       
    int = int + 1;
       console.log('int = ',int);
       
       scene = 6;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){
       
    cha = cha + 1;
       console.log('cha = ',cha);
       
       scene = 6;
     }
    
    console.log('_____');  
    console.log('Your characters stats',);
    console.log('strength = ',str);
    console.log('dexterity = ', dex);
    console.log('intelligence = ',int);
    console.log('charisma = ',cha);
      
    }
  
  else if(scene === 6){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       scene = 7;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       scene = 7;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 7;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 7;
     }
  }
  
  else if(scene === 7){
        if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
          
          rolldice();
          console.log('you have rolled', rollresult)
        if(rollresult + str > 3){
          scene = 8;
          console.log('You duck his strike and follow up with a backhanded strike that fells the bandit, his life whether lit or cold being none of your concern, you continue onward')
        }
          else{
            scene = 9;
          }
          
          
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
        rolldice();
          console.log('you have rolled', rollresult)
        if(rollresult + dex > 5){
          scene = 8;
          console.log('You shoot at him from afar, sinking an arrow into his chest. He falls to the ground violently, ceasing to move only moments later. Now dispatched, you continue onward.')
        }
          else{
            scene = 9;
          }
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
        rolldice();
          console.log('you have rolled', rollresult)
        if(rollresult + int > 8){
          console.log('You move your hands in the way your tome described, channeling mana through your blood. You whip your arm toward him with your fingers together standing over your thumb as your other hand holds the tome you are reading the spell from. 3 glowing prismatic darts fly out from the space you waved from. You are pleasantly surprised and relieved to see the bandit falling just a mere two steps away from you with 3 piercing wounds in his chest and head. Astounded at your discovery from this first test in actual combat, you feel confident you could do it again if you wish. You study your tome and take some notes a spellbook, and continue onward. ')
          console.log('Magic missile learned')
          MagicMisile = 1;
          scene = 8;
        }
          else{
            scene = 9;
          }
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
        rolldice();
          console.log('you have rolled', rollresult)
        if(rollresult + cha > 7){
          console.log('The bandit, staying his hand to hear you out, is impressed with your proposal. You learn he was a former guard has fallen on hard times and is happy that you desire his help for he has the rest of the town has branded him an outcast. He tells you his name is Humphrey, hands you a hatchet from his belt as a sign of and agrees to join you on your journey');
          str = str + 1
          console.log('str = ',str);
          console.log('Humphrey joins you');
          Humphrey = true;
          scene = 8;
        }
          else{
            scene = 9;
          }
     }
  }
  
    else if(scene === 8){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       scene = 10;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       scene = 10;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 13;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 13;
     }
  }
  
  else if(scene === 9){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
 
  
  
   str.reset();
   dex.reset();
   int.reset();
   cha.reset();
   Humphrey.reset();

   MagicMissile.reset();
   Fireball.reset();
    GhostSound.reset();
    sword.reset();
      longbow.reset();
    spellbook.reset(); 
      scene = 1;
      
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
           str.reset();
   dex.reset();
   int.reset();
   cha.reset();
   Humphrey.reset();

   MagicMissile.reset();
   Fireball.reset();
    GhostSound.reset();
    sword.reset();
      longbow.reset();
    spellbook.reset(); 
      scene = 1;

                 scene = 1;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){        
   str.reset();
   dex.reset();
   int.reset();
   cha.reset();
   Humphrey.reset();

   MagicMissile.reset();
   Fireball.reset();
    GhostSound.reset();
    sword.reset();
      longbow.reset();
    spellbook.reset(); 
      scene = 1;
                 scene = 1;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
           str.reset();
   dex.reset();
   int.reset();
   cha.reset();
   Humphrey.reset();

   MagicMissile.reset();
   Fireball.reset();
    GhostSound.reset();
    sword.reset();
      longbow.reset();
    spellbook.reset(); 
      scene = 1;
                 scene = 1;
     }
  }
  
      else if(scene === 10){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       rolldice();
      console.log('you have rolled', rollresult)
      if(rollresult + dex > 13){
        
        console.log("You outrun the beast ----");
        scene = 11;
      }
      
      else if(rollresult + dex < 13 && Humphrey === true){
      console.log("As you attempt to outrun the beast, it is too fast and snatches up Humphrey, leaving you to outrun his screams")}
      
      else{
        scene = 9;
      }
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
                 rolldice();
                 console.log('you have rolled', rollresult)
            if(rollresult + str && dex > 10 ){
                   console.log("Slay beast ----");
                scene = 11;                                                                }
          else if(rollresult + str && dex + 3 > 10 && Humphrey == true){
      console.log("the combined efforts of you and Humphrey slay the beast");
                                                                                        
                                                                                }
                                                                                
                                                                                
    else(scene = 9);
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 105;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      if(rollresult + dex > 4){
                 console.log("you hide in the brush and remain completely still. the beast, confused as to where its prey has gone, appears to listen for your breathing. As it closes upon you, it hears a sound off in the distance, and eventually moves far enough away from you that you can continue on unharmed and leave its hunting ground")
               }
       scene = 11;
     }
  }
  
   else if(scene === 105){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       rolldice();
      console.log('you have rolled', rollresult)
      if(rollresult + dex > 2){
        console.log("The beast becomes misdirected by the rock you threw, snapping at the reeds you threw the stone at and scaring off some animals hiding in the brush, sending it further away from your hiding spot.")
        scene = 11;
      }
      else{
        scene = 9;
      }
      
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       scene = 106;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
                 rolldice();
      console.log('you have rolled', rollresult)
      if(rollresult + int > 9 && rollresult + cha > 4){
        console.log("After a brief imitation of the beasts sounds along with some erratic clacking movements, the beast believes that it is in your hunting ground and leaves")
        
        scene = 11;
      }
      else{
        scene = 9;
      }
       
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      scene = 107;
       
     }
  }
  
  else if(scene === 106){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       rolldice();
      console.log('you have rolled', rollresult)
      if(rollresult + str + dex > 6){
        console.log("You pounce the beasts weak point and slice at it, allowing you time to escape as it writhes and snaps about in pain")
      scene = 11;
      }
      
      else {
        scene = 9;
      }
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
                 rolldice();
                 console.log('you have rolled', rollresult)                                                               
      if(rollresult + str > 9){
       console.log("you charge with all your might and cleave the leg in two, allowing you to decapitate the beast as it falls writhing to the ground");
      
        
        scene = 11; 
      }
  else{
    scene = 9;
  }
       
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
                 rolldice();
    console.log('you have rolled', rollresult)
                                                                                if(rollresult + int > 8){
                                                                                  console.log("The beast goes up in a burst of flames, and runs off some distance before collapsing to the ground as its life is extinguished by the flames.")
 scene = 11;                                                                               } 
       else{
    scene = 9;
  }
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      console.log("Humphrey cuts the beasts leg clean off as it approaches you, allowing you to end the beast as it falls to the ground")
       scene = 11;
     }
  }
  
  else if(scene === 107){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
      rolldice();
      console.log('you have rolled', rollresult)
      if(MagicMissile == 1 && rollresult + int > 8){
      console.log('')  
      
      scene = 11;}
      else if(MagicMissile == 0 && rollresult + int > 11){
              console.log('')
        console.log('Magic Missle Learned')
        MagicMissile = 1;
        scene = 11;
              }
      else{
        scene = 9;
      }
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){ 
                 rolldice();
      console.log('you have rolled', rollresult)
                 if(rollresult + int > 4 && rollresult + dex){
          
          console.log('You cast a fireball within the gaseous swamp at the beast, resulting in a blast that you were able')         
        console.log('Fireball Learned')
        Fireball = 1;
                 }
                   
                   else if(rollresult + int > 4 && rollresult + dex < 4){
                     
        console.log('You successfully cast a fireball in the gaseous swamp, resulting in an explosion that, while your cast destroyed the beast, hit you in the burst. The flames burned your arm and your caused your spellbook to erupt in molt of cinder')
        spellbook = 0;
          console.log('You no longer have a spellbook')
                   }
                     
                     else{
                       scene = 9
                     }
       scene = 11;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){ 
                 rolldice();
      console.log('you have rolled', rollresult)
                 console.log('')
       scene = 11;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
                 rolldice();
      console.log('you have rolled', rollresult)
                 
       scene = 11;
     }
  }
  
  else if(scene === 11){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
      
      console.log('As you attempt to say hello to these monsters, they shriek and hiss at you as the eggs around you crack open and many more pour out. The monsters attempt to swarm you.')
      scene = 12;
      
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){ 
                 rolldice();
      console.log('you have rolled', rollresult)
                 if(rollresult + dex > 6){
                   console.log('You manage to sneak around the monsters and find a pass through the cliffs far away without being detected.')
       scene = 20;
               }
                else{
                   console.log('You hear the sentries shriek behind you as you fumble about the eggs. Many more of the creatures start to hatch from the eggs and within moments you find yourself being swarmed')
                  scene = 12;
                 }
  
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 115;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
  }
  }
  
  else if(scene === 115){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
      
       scene = 1;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 116;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
  }
  
  else if(scene === 116){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
      rolldice();
      console.log('you have rolled', rollresult) 
      scene = 1;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       rolldice();
      console.log('you have rolled', rollresult)
                 scene = 1;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       rolldice();
      console.log('you have rolled', rollresult)
                 scene = 1;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
  }
    
    else if(scene === 12){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       scene = 1;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 1;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
  }
  
    
    else if(scene === 125){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
       scene = 1;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){      
       scene = 1;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){      
       scene = 1;
     }
  }
    
    else if(scene === 13){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
                console.log('You feel a push behind you, you and fall through the chasm')
       scene = 14;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){ 
                 console.log('The words on the rock glow a bright blue and rearrange themselves to say Welcome Home Fae One')
            
       scene = 17;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){
                 console.log('You feel a push behind you, and you fall through the chasm')
       scene = 14;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){ 
                 console.log('You feel a push behind you, and you fall through the chasm')
       scene = 14;
     }
  }
    else if(scene === 18){
    
    if(mouseX > 100 && mouseX < 400 && mouseY > 765 && mouseY < 845){
                console.log('')
       scene = 14;
     }
          
               if(mouseX > 300 && mouseX < 600 && mouseY > 665 && mouseY < 745){ 
                 console.log('')
            
       scene = 17;
     }
          
               if(mouseX > 500 && mouseX < 800 && mouseY > 765 && mouseY < 845){
                 console.log('')
       scene = 14;
     }
          
               if(mouseX > 700 && mouseX < 1000 && mouseY > 665 && mouseY < 745){ 
                 console.log('')
       scene = 14;
     }
  }
    
  
  
}

 //https://editor.p5js.org/kjhollen/sketches/WOZJmaBhZ







// networking main key
// opps as student

// internships
// do help and assist students in finding internships
// clubs like video game dev club
// guy comes and speaks
// be brash and bibaso
// interships are CRITICAL
// websites with indie devs
// website called fever, can have game dev
// mobile games a lot easier for entrance
// dry cold knock will be harder but no stop doing it
// try making own studio with people already know
// have published
// publishing at simplest form is a lot more than green college student without shit but degree
// keep applying
// side hustle is what it kind of is like
// aim for main hustle
// consider other options
// degree no define career
// consider grad school
// linked in learning
// lean into any free access too
// find friends and mobile places 
// do the wiggle
  